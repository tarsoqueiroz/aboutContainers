## 1. Getting Started With The Application

```sh
$ git clone https://github.com/raj713335/react-keycloak.git
$ cd raj713335/react-keycloak
$ npm i
$ npm start
```
