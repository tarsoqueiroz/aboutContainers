## 1. Getting Started With The Fast API Application

```sh
$ git clone https://github.com/raj713335/python-keycloak-fast-api.git
$ cd python-keycloak-fast-api
$ pip install -r requirements.txt
$ python main.py
```
